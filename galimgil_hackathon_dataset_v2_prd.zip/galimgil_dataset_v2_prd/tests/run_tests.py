import sys,copy,unittest,hashlib,json,csv
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from engine import *
class Tests(unittest.TestCase):
 def test_cases(self):
  for c in load('tests/test_cases.json')['records']:
   with self.subTest(case=c['id']):
    s=copy.deepcopy(load('synthetic/scenarios.json')['records'][0]);st=s['initial_state'];st.update(c.get('state_patch',{}));st['stats'].update(c.get('stats_patch',{}))
    if c['operation']=='probability':fn=lambda:probability(st,node(c['node_id']))
    elif c['operation']=='validate':fn=lambda:validate(st)
    elif c['operation']=='recover':fn=lambda:recover(st,c['kind'])
    if 'error' in c:
     with self.assertRaisesRegex(ValueError,'^'+c['error']+'$'):fn()
    else:self.assertEqual(fn(),c['expected'])
 def test_integrity(self):
  js=load('synthetic/jurors.json')['records'];ks=sum([load('synthetic/'+c+'_knowledge.json')['records'] for c in ['employment','relationship']],[])
  for rows,key in [(js,'juror_id'),(ks,'knowledge_id'),(load('synthetic/scenarios.json')['records'],'scenario_id'),(load('synthetic/career_nodes.json')['records'],'node_id')]:self.assertEqual(len(rows),len({r[key] for r in rows}))
  for j in js:self.assertAlmostEqual(sum(j['stat_weights'].values()),1);self.assertEqual(set(j['stat_weights']),set(S))
  for s in load('synthetic/scenarios.json')['records']:self.assertTrue(set(s['knowledge_ids'])<={k['knowledge_id'] for k in ks});evaluate(s)
  self.assertEqual(load('official/occupations.json')['records'],[])
 def test_events_and_boundaries(self):
  s=load('synthetic/scenarios.json')['records'][0];p=evaluate(s)['options'][0]['game_probability']
  self.assertEqual(simulate(s,'A',p,.9,0)['outcome'],'failure');self.assertEqual(simulate(s,'A',p-.000001,.9,0)['outcome'],'success')
  for roll in [0,.999]:
   self.assertIsNone(simulate(s,'A',roll,.28,0)['event_id']);self.assertEqual(simulate(s,'A',roll,.2799,0)['event_id'],'mentor')
  st=copy.deepcopy(s['initial_state']);st['funds_manwon']=20
  self.assertEqual(simulate(s,'A',0,0,.45,st)['state']['funds_manwon'],0)
  st['stats']={k:CAP[k] for k in S};self.assertEqual(simulate(s,'A',0,0,.99,st)['state']['stats']['mental'],8)
  st['stats']['mental']=0;self.assertEqual(simulate(s,'A',.999,0,.25,st)['state']['stats']['mental'],0)
 def test_bonus_goal(self):
  s=copy.deepcopy(load('synthetic/scenarios.json')['records'][1]);s['initial_state']['stats']['expertise']=3;s['initial_state']['next_application_bonus']=.1
  self.assertEqual(simulate(s,'A',0,.9,0)['state']['next_application_bonus'],0)
  self.assertEqual(simulate(s,'A',0,0,.65)['state']['next_application_bonus'],.1)
  s['options'][0]['node_id']='apply_goal';self.assertFalse(simulate(s,'A',0,.9,0)['destination_reached'])
  s['initial_state']['stats'].update(expertise=5,practical=4,awards=1);self.assertTrue(simulate(s,'A',0,.9,0)['destination_reached'])
 def test_history_time_recovery(self):
  s=copy.deepcopy(load('synthetic/scenarios.json')['records'][0]);st=s['initial_state'];st['qualifications']=['SQLD']
  rec=recommend(st);self.assertTrue(all(len(v)<=2 for v in rec.values()));self.assertNotIn('cert_sql',[r['node_id'] for rs in rec.values() for r in rs])
  st['elapsed_months']=70;self.assertIn('time_limit',evaluate(s)['options'][0]['reasons'])
  st['elapsed_months']=69;self.assertTrue(simulate(s,'A',.999,.9,0)['interim_report'])
  st['elapsed_months']=0;st['funds_manwon']=0
  for i in range(2):st=recover(st,'part_time');self.assertEqual(st['part_time_uses'],i+1);st['funds_manwon']=0
  self.assertNotIn('part_time',recovery_available(st))
  st['stats']['mental']=1;st=recover(st,'rest');self.assertEqual(st['stats']['mental'],3)
 def test_branches_relationship(self):
  s=load('synthetic/scenarios.json')['records'][0];st=copy.deepcopy(s['initial_state']);tree={'root':{'state_after':st}}
  branch(tree,'root','a','cert_ip',simulate(s,'A',0,.9,0));branch(tree,'root','b','proj_ai',simulate(s,'B',0,.9,0));self.assertEqual(len(tree),3);self.assertEqual(tree['root']['state_after'],st);self.assertNotEqual(tree['a']['state_after'],tree['b']['state_after'])
  rs={r['scenario_id']:r for r in load('synthetic/scenarios.json')['records']}
  self.assertEqual(simulate(rs['rel_s01'],'A')['state'],rs['rel_s01']['initial_state']);self.assertEqual(evaluate(rs['rel_s09'])['mode'],'safety_review');self.assertFalse(evaluate(rs['rel_s08'])['options'][1]['feasible'])
 def test_files(self):
  for p in B.rglob('*.json'):json.loads(p.read_text(encoding='utf-8'))
  for r in load('manifest.json')['files']:self.assertEqual(hashlib.sha256((B/r['path']).read_bytes()).hexdigest(),r['sha256'])
  for p in (B/'csv').glob('*.csv'):
   with p.open(encoding='utf-8-sig',newline='') as f:self.assertTrue(list(csv.DictReader(f)))
if __name__=='__main__':unittest.main(verbosity=2)
