import json,copy,math
from pathlib import Path
B=Path(__file__).resolve().parent
S=['expertise','practical','awards','network','mental'];CAP=dict(zip(S,[10,10,10,10,8]))
def load(n):return json.loads((B/n).read_text(encoding='utf-8'))
def integer(x,lo=0,hi=None):return type(x) is int and x>=lo and (hi is None or x<=hi)
def validate(st):
 if set(st.get('stats',{}))!=set(S) or not all(integer(st['stats'][k],0,CAP[k]) for k in S):raise ValueError('invalid_stats')
 if not integer(st.get('funds_manwon')) or not integer(st.get('elapsed_months'),0,72) or not integer(st.get('part_time_uses'),0,2):raise ValueError('invalid_resources')
 if type(st.get('next_application_bonus')) not in (int,float) or st['next_application_bonus'] not in (0,.1):raise ValueError('invalid_bonus')
 for k in ['completed_node_ids','qualifications']:
  if not isinstance(st.get(k),list) or not all(isinstance(v,str) for v in st[k]):raise ValueError('invalid_history')
def node(id):
 n=next((n for n in load('synthetic/career_nodes.json')['records'] if n['node_id']==id),None)
 if n is None:raise ValueError('unknown_node')
 return n
def probability(st,n):
 validate(st);v=st['stats']
 if n['type']=='application':
  cap=.85 if n['application_kind']=='intern' else .8;req=n['requirements']
  if not req:raise ValueError('empty_requirements')
  ratio=sum(v[k]>=r for k,r in req.items())/len(req)
  p=cap if ratio==1 else .08+(cap-.08)*ratio
  p+=st['next_application_bonus']
 else:
  p=n['base_probability']+(v['expertise']+v['practical']-3)*.04
  if n['type']=='competition':p+=v['awards']*.04
 if v['mental']<=1:p-=.15
 return round(max(.05,min(.95,p)),6)
def reasons(st,n):
 r=[]
 if n['cost_manwon']>st['funds_manwon']:r.append('insufficient_funds')
 if st['elapsed_months']+n['duration_months']>72:r.append('time_limit')
 if n['node_id'] in st['completed_node_ids']:r.append('already_completed')
 if n['grants_qualification'] and n['grants_qualification'] in st['qualifications']:r.append('already_qualified')
 return r
def evaluate(s,state=None):
 st=state if state is not None else s['initial_state'];validate(st)
 if [o['option_id'] for o in s['options']]!=['A','B']:raise ValueError('invalid_options')
 if s['category']=='relationship':
  if 'coercion' in s['flags']:return {'mode':'safety_review','winner':None,'options':[]}
  return {'mode':'discussion_only','winner':None,'options':[{'option_id':o['option_id'],'feasible':o['gate']=='allowed','reasons':[] if o['gate']=='allowed' else [o['gate']],'game_probability':None,'score':None} for o in s['options']]}
 if s['category']!='employment':raise ValueError('unknown_category')
 occupations={o['occupation_id'] for f in ['synthetic/occupations.json','official/occupations.json'] for o in load(f)['records']}
 if s['target_occupation_id'] not in occupations:raise ValueError('unknown_occupation')
 js={j['juror_id']:j for j in load('synthetic/jurors.json')['records']};panel=[js[i] for i in s['juror_ids']]
 if not panel or len(panel)!=len(set(s['juror_ids'])):raise ValueError('invalid_panel')
 for j in panel:
  w=j['stat_weights']
  if j['category']!='employment' or set(w)!=set(S) or any(type(v) not in (int,float) or not math.isfinite(v) or v<0 for v in w.values()) or abs(sum(w.values())-1)>1e-9:raise ValueError('invalid_weights')
 out=[]
 for o in s['options']:
  n=node(o['node_id']);r=reasons(st,n);p=probability(st,n) if not r else None
  scores={j['juror_id']:round(sum(j['stat_weights'][k]*(p*n['success_delta'][k]+(1-p)*n['failure_delta'][k]) for k in S),6) for j in panel} if p is not None else {}
  out.append({'option_id':o['option_id'],'node_id':n['node_id'],'feasible':not r,'reasons':r,'game_probability':p,'juror_scores':scores,'score':round(sum(scores.values())/len(scores),6) if scores else None})
 eligible=[r for r in out if r['feasible']]
 if not eligible:return {'mode':'no_feasible_option','winner':None,'options':out}
 top=max(r['score'] for r in eligible);ids=[r['option_id'] for r in eligible if r['score']==top]
 return {'mode':'scored','winner':ids[0] if len(ids)==1 else 'tie','options':out}
def roll_valid(x):return type(x) in (int,float) and math.isfinite(x) and 0<=x<1
def simulate(s,option_id,success_roll=None,event_roll=None,event_type_roll=None,state=None):
 st=copy.deepcopy(state if state is not None else s['initial_state']);r=evaluate(s,st)
 if r['mode']=='safety_review':raise ValueError('safety_review')
 o=next((o for o in r['options'] if o['option_id']==option_id),None)
 if o is None or not o['feasible']:raise ValueError('infeasible_option')
 if s['category']=='relationship':return {'outcome':'not_simulated','state':st}
 if not all(roll_valid(x) for x in [success_roll,event_roll,event_type_roll]):raise ValueError('invalid_roll')
 n=node(o['node_id']);ok=success_roll<o['game_probability'];qualified=all(st['stats'][k]>=v for k,v in n['requirements'].items())
 st['funds_manwon']-=n['cost_manwon'];st['elapsed_months']+=n['duration_months']
 for k,v in n['success_delta' if ok else 'failure_delta'].items():st['stats'][k]+=v
 if n['type']=='application':st['next_application_bonus']=0
 if ok:
  st['funds_manwon']+=n['income_manwon'];st['completed_node_ids'].append(n['node_id'])
  if n['grants_qualification']:st['qualifications'].append(n['grants_qualification'])
 event=None
 if event_roll<.28:
  event=load('events.json')['records'][min(4,int(event_type_roll*5))]
  for k,v in event['stat_delta'].items():st['stats'][k]+=v
  st['funds_manwon']=max(0,st['funds_manwon']+event['funds_delta_manwon'])
  if event['event_id']=='hiring':st['next_application_bonus']=.1
 for k in S:st['stats'][k]=max(0,min(CAP[k],st['stats'][k]))
 reached=ok and qualified and n['node_id']=='apply_goal'
 return {'outcome':'success' if ok else 'failure','event_id':event['event_id'] if event else None,'game_probability':o['game_probability'],'destination_reached':reached,'interim_report':st['elapsed_months']==72 and not reached,'state':st}
def recovery_available(st):
 validate(st);out=[];ns=load('synthetic/career_nodes.json')['records']
 if st['part_time_uses']<2 and st['elapsed_months']+3<=72 and (any('insufficient_funds' in reasons(st,n) for n in ns) or not any(not reasons(st,n) for n in ns)):out.append('part_time')
 if st['stats']['mental']<=1 and st['elapsed_months']+1<=72:out.append('rest')
 return out
def recover(st,kind):
 if kind not in recovery_available(st):raise ValueError('recovery_unavailable')
 st=copy.deepcopy(st)
 if kind=='part_time':st['funds_manwon']+=300;st['elapsed_months']+=3;st['part_time_uses']+=1;st['stats']['mental']=max(0,st['stats']['mental']-1)
 else:st['elapsed_months']+=1;st['stats']['mental']=min(8,st['stats']['mental']+2)
 return st
def recommend(st):
 validate(st);req={'expertise':5,'practical':4,'awards':1};groups={}
 for n in load('synthetic/career_nodes.json')['records']:
  r=reasons(st,n)
  if 'already_completed' in r or 'already_qualified' in r:continue
  priority=sum(max(0,v-st['stats'][k])*max(0,n['success_delta'][k]) for k,v in req.items())
  groups.setdefault(n['type'],[]).append({'node_id':n['node_id'],'priority':priority,'disabled_reasons':r})
 return {k:sorted(v,key=lambda x:(-x['priority'],x['node_id']))[:2] for k,v in groups.items()}
def branch(tree,parent,path_id,activity_id,result):
 if path_id in tree:raise ValueError('duplicate_path')
 if parent not in tree:raise ValueError('unknown_parent')
 tree[path_id]={'parent_id':parent,'activity_id':activity_id,'state_before':copy.deepcopy(tree[parent]['state_after']),'result':copy.deepcopy(result),'state_after':copy.deepcopy(result['state'])}
 return path_id
if __name__=='__main__':print(json.dumps(evaluate(load('synthetic/scenarios.json')['records'][0]),ensure_ascii=False,indent=2))
